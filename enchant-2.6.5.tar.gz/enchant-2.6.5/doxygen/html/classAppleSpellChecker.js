var classAppleSpellChecker =
[
    [ "AppleSpellChecker", "classAppleSpellChecker.html#a96fe41e818a329ee7a8d9bdba5945f94", null ],
    [ "~AppleSpellChecker", "classAppleSpellChecker.html#a9e84e16aa4b13663dd7437df7c888ac7", null ],
    [ "checkWord", "classAppleSpellChecker.html#a6ce7d3cd30ef3dcb7e59767587304ca1", null ],
    [ "listDictionaries", "classAppleSpellChecker.html#a00c9735a742052ab33520b685e5d96fe", null ],
    [ "parseConfigFile", "classAppleSpellChecker.html#a9abb1b71a060cb32ec8f24bb876e3b6d", null ],
    [ "requestDictionary", "classAppleSpellChecker.html#a4249242b582de3b62e30fe348383005f", null ],
    [ "suggestWord", "classAppleSpellChecker.html#ae5fd27669f48b6d70f2635c5e1b12f90", null ]
];