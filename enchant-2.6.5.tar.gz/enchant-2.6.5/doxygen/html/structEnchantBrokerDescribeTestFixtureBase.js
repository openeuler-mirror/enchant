var structEnchantBrokerDescribeTestFixtureBase =
[
    [ "EnchantBrokerDescribeTestFixtureBase", "structEnchantBrokerDescribeTestFixtureBase.html#a222c387737b2c63beef93d7f43ea90f3", null ],
    [ "_providerList", "structEnchantBrokerDescribeTestFixtureBase.html#a8c8b4e16aa2de44f3218ba016f38067a", null ]
];