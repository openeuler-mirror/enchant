var structEnchantBrokerTestFixture =
[
    [ "EnchantBrokerTestFixture", "structEnchantBrokerTestFixture.html#a68bc650f9f5be3bdedcf4374b8f24cf3", null ],
    [ "~EnchantBrokerTestFixture", "structEnchantBrokerTestFixture.html#a840f875ac806c87fd26c4d72627af3eb", null ],
    [ "CopyProvider", "structEnchantBrokerTestFixture.html#a03fdcd0a3a7ad13cbf235d515c9ff1fd", null ],
    [ "FreeDictionary", "structEnchantBrokerTestFixture.html#a69512877d27b955d92fa1f76366a4047", null ],
    [ "GetLastPersonalDictionaryFileName", "structEnchantBrokerTestFixture.html#a8157e084f7bc370a995d88fc4bacb039", null ],
    [ "GetMockProvider", "structEnchantBrokerTestFixture.html#ad629703fa27b4dc3b3039b29e72da0f7", null ],
    [ "InitializeBroker", "structEnchantBrokerTestFixture.html#a3ddad5e76ca32d1d1c307ebbdd59b2b9", null ],
    [ "RequestDictionary", "structEnchantBrokerTestFixture.html#a5e5457df28e7829575f7b474e74aa0a1", null ],
    [ "RequestPersonalDictionary", "structEnchantBrokerTestFixture.html#acdd320079014eeef074ce7d772ec9e88", null ],
    [ "SetErrorOnMockProvider", "structEnchantBrokerTestFixture.html#a28e0254a824e1b6b8e1c0e1bd956cd91", null ],
    [ "_broker", "structEnchantBrokerTestFixture.html#ae96570c2d0b5da55fe976b4c62b8bce0", null ],
    [ "hModule", "structEnchantBrokerTestFixture.html#ad3ba41a48521baf4f163e3cd01505bdf", null ],
    [ "hModule2", "structEnchantBrokerTestFixture.html#ab8551cc34a27f00baad05cd5c0a2e6c6", null ]
];