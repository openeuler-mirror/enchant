var structDictionarySuggest__TestFixture =
[
    [ "DictionarySuggest_TestFixture", "structDictionarySuggest__TestFixture.html#a18c3bb514f632bdbec461f235bfce18d", null ],
    [ "~DictionarySuggest_TestFixture", "structDictionarySuggest__TestFixture.html#a80947abc7e88addb4f910f0cfe11dfa2", null ],
    [ "GetSuggestionsFromWord", "structDictionarySuggest__TestFixture.html#a30e1cb1545c79b3d189beec253ef03b6", null ],
    [ "GetSuggestionsFromWord", "structDictionarySuggest__TestFixture.html#a58a13f15f363362513916ea3730e32df", null ],
    [ "IsFirstLetterCapitalOrTitleCase", "structDictionarySuggest__TestFixture.html#a404092cdba3df20e2308d8a160a47ecc", null ],
    [ "IsWordAllCaps", "structDictionarySuggest__TestFixture.html#ad9f947df73af6a7d5e4027f95699d56e", null ],
    [ "_addedWords", "structDictionarySuggest__TestFixture.html#ac720af9caada311cfecb71f71ddc4f8d", null ],
    [ "_dict", "structDictionarySuggest__TestFixture.html#a3ba284ae73e76ae9d1d6d3d480186765", null ],
    [ "_provider_name", "structDictionarySuggest__TestFixture.html#aaddc44d153400620fe961aabd9127da9", null ]
];