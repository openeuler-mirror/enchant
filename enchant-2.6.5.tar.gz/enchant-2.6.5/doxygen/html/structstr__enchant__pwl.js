var structstr__enchant__pwl =
[
    [ "file_changed", "structstr__enchant__pwl.html#ab43b6ac6fb3d326b7364786a54567a8c", null ],
    [ "filename", "structstr__enchant__pwl.html#aaed61e829a41bae4cdcc635c380e47e9", null ],
    [ "words", "structstr__enchant__pwl.html#aecfe408cf578c8a438321cf98650ddc0", null ]
];