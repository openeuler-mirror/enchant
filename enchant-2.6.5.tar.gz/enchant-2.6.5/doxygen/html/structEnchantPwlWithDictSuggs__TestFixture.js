var structEnchantPwlWithDictSuggs__TestFixture =
[
    [ "EnchantPwlWithDictSuggs_TestFixture", "structEnchantPwlWithDictSuggs__TestFixture.html#ae0b0156964c9de2432e033e300e5c969", null ]
];