var structEnchantBrokerSetErrorTests =
[
    [ "EnchantBrokerSetErrorTests", "structEnchantBrokerSetErrorTests.html#a2bb1d8f61728a1221f82e0c05028c615", null ],
    [ "GetErrorMessage", "structEnchantBrokerSetErrorTests.html#ada174ae60db2c46d9a65df10450e72d7", null ],
    [ "provider", "structEnchantBrokerSetErrorTests.html#aec4a9a09611f80603f40c7ad53b09c21", null ]
];