var structstr__enchant__broker =
[
    [ "dict_map", "structstr__enchant__broker.html#a6c45056cc4b2c22894c349167ec34365", null ],
    [ "error", "structstr__enchant__broker.html#a8e02432ca069c04e717f130d0c88d8ac", null ],
    [ "provider_list", "structstr__enchant__broker.html#ae0daa2e67b3bd5e172e84eeb7713c2c2", null ],
    [ "provider_ordering", "structstr__enchant__broker.html#aea3170f05e96b53ffa3da036c28c4a31", null ]
];