var classenchant_1_1Dict =
[
    [ "~Dict", "classenchant_1_1Dict.html#abfd1e8649d47893103557f5d876afa58", null ],
    [ "add", "classenchant_1_1Dict.html#a768ee180ff0aef07583a5028a2dc2218", null ],
    [ "add_to_session", "classenchant_1_1Dict.html#aeed8562f497fc92b80e219e74b84725e", null ],
    [ "check", "classenchant_1_1Dict.html#a517a7f986df99ea801afe786bbfb862b", null ],
    [ "get_lang", "classenchant_1_1Dict.html#a379cc6b59430aba40ab197af3c78bf6d", null ],
    [ "get_provider_desc", "classenchant_1_1Dict.html#a233a13519cd77383b1f64dafa927f48e", null ],
    [ "get_provider_file", "classenchant_1_1Dict.html#aa7bcc783188e289d8b22b7a24c0a5ca9", null ],
    [ "get_provider_name", "classenchant_1_1Dict.html#af793d85e2cafdb7514f000376dda4006", null ],
    [ "is_added", "classenchant_1_1Dict.html#ab773e7857146c9af5ba82f9ba0a6673b", null ],
    [ "is_removed", "classenchant_1_1Dict.html#a7cf9704bf69845d77aeda24ddbb858fc", null ],
    [ "remove", "classenchant_1_1Dict.html#a6deb5367e0e7e603f65d1b5709427f23", null ],
    [ "remove_from_session", "classenchant_1_1Dict.html#a8c9b01adacf9ea39cc928cfdded99b44", null ],
    [ "store_replacement", "classenchant_1_1Dict.html#aa2f9e65ea61c6e4040f4ab45f01e3cf4", null ],
    [ "suggest", "classenchant_1_1Dict.html#a89a99e9586fad9c93ce455f7f3cfa956", null ],
    [ "suggest", "classenchant_1_1Dict.html#aef97c608cb54f47be163c8912be2aad7", null ],
    [ "enchant::Broker", "classenchant_1_1Dict.html#a35b30ed0d79d43e2b770e09cd3afae3e", null ]
];