var structEnchantDictionarySuggest__TestFixture =
[
    [ "EnchantDictionarySuggest_TestFixture", "structEnchantDictionarySuggest__TestFixture.html#ad918c4ba7d6558ab9ab0e5b05ffca090", null ]
];