var structAppleSpellDictionary =
[
    [ "AppleSpell", "structAppleSpellDictionary.html#a4747deb70ac09801ab92b5db476e94f1", null ],
    [ "DictionaryName", "structAppleSpellDictionary.html#ad9da863ef9016e81a073adfa94eef1da", null ]
];