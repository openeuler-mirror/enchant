var structEnchantDictionaryDescribe__TestFixtureBase =
[
    [ "EnchantDictionaryDescribe_TestFixtureBase", "structEnchantDictionaryDescribe__TestFixtureBase.html#a671a2e71b30a8b9a0d4b2d2e4c0d9a7a", null ],
    [ "_description", "structEnchantDictionaryDescribe__TestFixtureBase.html#aec36e6143acf9fb496c4e855519eeffd", null ]
];