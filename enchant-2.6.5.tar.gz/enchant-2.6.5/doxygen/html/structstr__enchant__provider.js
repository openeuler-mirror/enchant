var structstr__enchant__provider =
[
    [ "describe", "structstr__enchant__provider.html#a0f09680ef13411e32242377352bb8eb5", null ],
    [ "dictionary_exists", "structstr__enchant__provider.html#a0ebc90dea4d4fede03bb4cfb81d2fcc4", null ],
    [ "dispose", "structstr__enchant__provider.html#ab52206d5fe36f702bbced26e39f8e7c6", null ],
    [ "dispose_dict", "structstr__enchant__provider.html#a822ed318153ce6c5ab6666389942beaa", null ],
    [ "enchant_private_data", "structstr__enchant__provider.html#a63267531231c849e7eb77c7a8d0ce63b", null ],
    [ "identify", "structstr__enchant__provider.html#ae6a736823b4b1927793b204e0798e665", null ],
    [ "list_dicts", "structstr__enchant__provider.html#a332e0d86bb1cc346c582968d09866288", null ],
    [ "owner", "structstr__enchant__provider.html#adfdaa88efa9817ec6816ba2edcf025be", null ],
    [ "request_dict", "structstr__enchant__provider.html#a9cd645320007ce3076f85d3f052380f5", null ],
    [ "user_data", "structstr__enchant__provider.html#a55bb5341acb8c706a24e72399b7a9f8f", null ]
];