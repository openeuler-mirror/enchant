var structProviderDescription =
[
    [ "ProviderDescription", "structProviderDescription.html#a961419849877e2ffb0a3d070ce10fc77", null ],
    [ "DataIsComplete", "structProviderDescription.html#a464b45f44d263eb2ce8bd5ddf6489c08", null ],
    [ "Description", "structProviderDescription.html#ae6f11aaf57a83f5ac3b7968fe73aab73", null ],
    [ "DllFile", "structProviderDescription.html#a799b4586be38fa27f2629316a52611fa", null ],
    [ "Name", "structProviderDescription.html#a998e2c15a06c2d0955e5be557bd7f8be", null ]
];