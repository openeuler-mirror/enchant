var structEnchantDictionaryGetExtraWordCharactersTestFixtureBase =
[
    [ "EnchantDictionaryGetExtraWordCharactersTestFixtureBase", "structEnchantDictionaryGetExtraWordCharactersTestFixtureBase.html#a65fbd1a9ccd3e0201489ec8d5caf8e6a", null ],
    [ "_extraWordCharacters", "structEnchantDictionaryGetExtraWordCharactersTestFixtureBase.html#a79b4ad53b939cc28e14a816245a17031", null ]
];