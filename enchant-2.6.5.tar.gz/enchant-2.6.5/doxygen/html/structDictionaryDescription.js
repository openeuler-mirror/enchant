var structDictionaryDescription =
[
    [ "DictionaryDescription", "structDictionaryDescription.html#a4fd697a0092c8369789dec613fb0a57d", null ],
    [ "DictionaryDescription", "structDictionaryDescription.html#a84253f6bdc9a576f1127f08f45c868a8", null ],
    [ "DictionaryDescription", "structDictionaryDescription.html#a71a19da4893431d7cbced9a770ef75ef", null ],
    [ "DataIsComplete", "structDictionaryDescription.html#a60d3ff2d0477f2411302ebe5abd45d68", null ],
    [ "Description", "structDictionaryDescription.html#aa485f2cea094c436edff20c18e67144f", null ],
    [ "DllFile", "structDictionaryDescription.html#af965aadd38ae37f89cfe60783b35c730", null ],
    [ "LanguageTag", "structDictionaryDescription.html#a42bfaf434efabdf079b47a801322ce41", null ],
    [ "Name", "structDictionaryDescription.html#a76057ab814adcc5770a0e3c02f2fe193", null ]
];