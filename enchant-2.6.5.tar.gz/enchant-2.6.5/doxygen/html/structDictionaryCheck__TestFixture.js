var structDictionaryCheck__TestFixture =
[
    [ "AddedWordsByDict", "structDictionaryCheck__TestFixture.html#a741f7e9e9cb4da62fd21e964c9a3a7cf", null ],
    [ "DictionaryCheck_TestFixture", "structDictionaryCheck__TestFixture.html#a8751fcde8661437649e50547eb1f7315", null ],
    [ "~DictionaryCheck_TestFixture", "structDictionaryCheck__TestFixture.html#a803a2a6135c49b4b6d61c5f9238c51b0", null ],
    [ "AddWordToDictionary", "structDictionaryCheck__TestFixture.html#a9d44815549d07b87437ebabd651842fc", null ],
    [ "AddWordToDictionary", "structDictionaryCheck__TestFixture.html#a70a69ae86eb19fa6e1ee45eed56e43fa", null ],
    [ "IsWordInDictionary", "structDictionaryCheck__TestFixture.html#aa99a0643d21911971035a55459d319c4", null ],
    [ "ReleaseDictionary", "structDictionaryCheck__TestFixture.html#ab1ae0f49f73cfa906f8df837f5deb5d0", null ],
    [ "_addedWordsByDict", "structDictionaryCheck__TestFixture.html#a59c75e187f9c5f29ed111ed62ef55adc", null ],
    [ "_dict", "structDictionaryCheck__TestFixture.html#a088d91adfee8d453a427638b2197cbac", null ],
    [ "_provider_name", "structDictionaryCheck__TestFixture.html#a6ab91251b389508247f7b96e37f32641", null ]
];