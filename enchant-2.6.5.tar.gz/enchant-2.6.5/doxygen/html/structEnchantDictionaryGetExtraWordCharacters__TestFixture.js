var structEnchantDictionaryGetExtraWordCharacters__TestFixture =
[
    [ "EnchantDictionaryGetExtraWordCharacters_TestFixture", "structEnchantDictionaryGetExtraWordCharacters__TestFixture.html#a2c22141bdaa0e8b6447174a668d8f245", null ]
];