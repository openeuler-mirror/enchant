var structEnchantDictionarySuggestTestFixtureBase =
[
    [ "EnchantDictionarySuggestTestFixtureBase", "structEnchantDictionarySuggestTestFixtureBase.html#a718f8329a082f962a33e0490f5a82518", null ],
    [ "~EnchantDictionarySuggestTestFixtureBase", "structEnchantDictionarySuggestTestFixtureBase.html#a88af18ee169ce39d4fd99f3f77dae309", null ],
    [ "_pwl_suggestions", "structEnchantDictionarySuggestTestFixtureBase.html#a3b7c0db6947f8f1d5df82951a8324927", null ],
    [ "_suggestions", "structEnchantDictionarySuggestTestFixtureBase.html#a7427120fc47cc577c24802ee1f568132", null ]
];