var structEnchantSession =
[
    [ "error", "structEnchantSession.html#a0ac4fa7f67e9624b8f81ba9666205e93", null ],
    [ "exclude", "structEnchantSession.html#a86955c385515521143b8e6c60824d7db", null ],
    [ "exclude_filename", "structEnchantSession.html#ab8ecd50620f4c7ac50243fa737c6035b", null ],
    [ "is_pwl", "structEnchantSession.html#aff8d5a02822ce314cc92b651ebfb04d0", null ],
    [ "language_tag", "structEnchantSession.html#a190f55a96af0d50cd7d99a930114c91e", null ],
    [ "personal", "structEnchantSession.html#ad5f1493f83800f1731915ef71db7d277", null ],
    [ "personal_filename", "structEnchantSession.html#a1ee42013006ff24df5a17451ba7086e0", null ],
    [ "provider", "structEnchantSession.html#aa6d68ecc0ec82983dc6ba2427b44d20a", null ],
    [ "session_exclude", "structEnchantSession.html#a0aa69bdccbe74996ee7fdee6fe81afef", null ],
    [ "session_include", "structEnchantSession.html#a9727cdbe3f2c181b636b02d756bf6619", null ]
];