var structEnchantDictionaryIsWordCharacterTestFixtureBase =
[
    [ "EnchantDictionaryIsWordCharacterTestFixtureBase", "structEnchantDictionaryIsWordCharacterTestFixtureBase.html#ab70a7a46232f2a475eee2b78aebdb04a", null ]
];