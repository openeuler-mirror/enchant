var structEnchantDictPrivateData =
[
    [ "reference_count", "structEnchantDictPrivateData.html#abce100b7b707eaa9e7ff6ee34cc279c9", null ],
    [ "session", "structEnchantDictPrivateData.html#a0c6b6cc7a7a6866cc0f285d5117c609f", null ]
];