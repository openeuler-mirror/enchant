var structEnchantGetPrefixDirTestFixture =
[
    [ "EnchantGetPrefixDirTestFixture", "structEnchantGetPrefixDirTestFixture.html#add23ebb2ccd267992f6922d6971eba5d", null ],
    [ "ExpectedPrefixDir", "structEnchantGetPrefixDirTestFixture.html#ad34fb2071d32b52af11f70e22dbaf577", null ],
    [ "expectedPrefixDir", "structEnchantGetPrefixDirTestFixture.html#abee09d59aec73e7e3d48341f2cd5e422", null ]
];