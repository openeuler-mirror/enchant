var structEnchantBrokerFreeDictTestFixture =
[
    [ "EnchantBrokerFreeDictTestFixture", "structEnchantBrokerFreeDictTestFixture.html#ad0883efd647a76d1befec4a7263f5e60", null ],
    [ "~EnchantBrokerFreeDictTestFixture", "structEnchantBrokerFreeDictTestFixture.html#aab53748199247886dce1c65953cf73e1", null ],
    [ "_dictionary", "structEnchantBrokerFreeDictTestFixture.html#af20cdb1653547ff615797026ec4f298b", null ]
];