var classZemberek =
[
    [ "Zemberek", "classZemberek.html#ae79a59a64c2acc8b8fe699e439676d65", null ],
    [ "~Zemberek", "classZemberek.html#a8809e1a4ab78fd54c0dbd5955f17fb5d", null ],
    [ "checkWord", "classZemberek.html#a4e37a21865b72ffdcc345feb3e45cab4", null ],
    [ "suggestWord", "classZemberek.html#abface3bfdd28df81d14d8ab569635214", null ]
];