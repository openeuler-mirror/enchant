var classenchant_1_1Exception =
[
    [ "Exception", "classenchant_1_1Exception.html#a1e953434e618f7442650cdf1a993554f", null ],
    [ "~Exception", "classenchant_1_1Exception.html#ab0fcf4b978f1f4e5939e3b2f05934cd3", null ],
    [ "what", "classenchant_1_1Exception.html#af3927e3ec45f8f2e6d2953f75f8312a5", null ]
];