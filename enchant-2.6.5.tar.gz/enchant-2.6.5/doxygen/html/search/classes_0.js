var searchData=
[
  ['applespellchecker_75',['AppleSpellChecker',['../classAppleSpellChecker.html',1,'']]],
  ['applespelldictionary_76',['AppleSpellDictionary',['../structAppleSpellDictionary.html',1,'']]]
];
