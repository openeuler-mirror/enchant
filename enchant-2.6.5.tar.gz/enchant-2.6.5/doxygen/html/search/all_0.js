var searchData=
[
  ['applespellchecker_0',['AppleSpellChecker',['../classAppleSpellChecker.html',1,'']]],
  ['applespelldictionary_1',['AppleSpellDictionary',['../structAppleSpellDictionary.html',1,'']]]
];
