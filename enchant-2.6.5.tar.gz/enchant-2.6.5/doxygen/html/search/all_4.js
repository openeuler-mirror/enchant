var searchData=
[
  ['hunspellchecker_62',['HunspellChecker',['../classHunspellChecker.html',1,'']]]
];
