var searchData=
[
  ['hunspellchecker_136',['HunspellChecker',['../classHunspellChecker.html',1,'']]]
];
