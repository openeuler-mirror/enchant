var structEnchantBrokerListDictionaries__TestFixtureBase =
[
    [ "EnchantBrokerListDictionaries_TestFixtureBase", "structEnchantBrokerListDictionaries__TestFixtureBase.html#ad549812afbee38ad0cfb51251ba9d4b6", null ],
    [ "_dictionaryList", "structEnchantBrokerListDictionaries__TestFixtureBase.html#aa1abd519546f3c2d00b16d3c9a457daa", null ]
];