var structProviderIdentify__TestFixture =
[
    [ "ProviderIdentify_TestFixture", "structProviderIdentify__TestFixture.html#aacd7d0ec8a06c1483dfc9ffe70d7ebd6", null ],
    [ "~ProviderIdentify_TestFixture", "structProviderIdentify__TestFixture.html#aed0cefc9fb5d9592571adcb0dfdb7e22", null ]
];