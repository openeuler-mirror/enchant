var structstr__enchant__dict =
[
    [ "add_to_session", "structstr__enchant__dict.html#afa485ebb8d750abc16dff51a20a6a302", null ],
    [ "check", "structstr__enchant__dict.html#a4f85b4f3a78b2a40807062b82ead3b1c", null ],
    [ "enchant_private_data", "structstr__enchant__dict.html#ac953913783e756cea50907ce096e4d91", null ],
    [ "get_extra_word_characters", "structstr__enchant__dict.html#a494a0363b8ac9657a9537e1c3d41f3d4", null ],
    [ "is_word_character", "structstr__enchant__dict.html#a85d3ee75a9e970b8e2464ef71cbe7e88", null ],
    [ "remove_from_session", "structstr__enchant__dict.html#a9ef81c677abbdb46f3de4d8050934bb9", null ],
    [ "suggest", "structstr__enchant__dict.html#aad26af8fff7bb7c94806d6038d509ed7", null ],
    [ "user_data", "structstr__enchant__dict.html#ad436901a1bf96da53d87d1189aba9390", null ]
];