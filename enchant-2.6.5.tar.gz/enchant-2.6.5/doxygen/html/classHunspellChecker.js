var classHunspellChecker =
[
    [ "HunspellChecker", "classHunspellChecker.html#afcfb06193627c36a267046c9fb9aad9d", null ],
    [ "~HunspellChecker", "classHunspellChecker.html#a57d9e167cc041a419d7e60ccba352acd", null ],
    [ "add", "classHunspellChecker.html#a2e8b27faf8ded2a743265442591b470c", null ],
    [ "checkWord", "classHunspellChecker.html#ad3e430091a9fa23ea316907eb92650c9", null ],
    [ "getWordchars", "classHunspellChecker.html#ad053da5ff1a6343836b5f38cd7b2a03b", null ],
    [ "remove", "classHunspellChecker.html#ad588a888e31fc94bf2b2968a86e34749", null ],
    [ "requestDictionary", "classHunspellChecker.html#a16f91d0e744ef394162647ae085c270e", null ],
    [ "suggestWord", "classHunspellChecker.html#ad5a5e980405e63ce5ba1034fd8da71b8", null ],
    [ "apostropheIsWordChar", "classHunspellChecker.html#af93e5cbb8eda0807211c3266a0ad9fdb", null ]
];