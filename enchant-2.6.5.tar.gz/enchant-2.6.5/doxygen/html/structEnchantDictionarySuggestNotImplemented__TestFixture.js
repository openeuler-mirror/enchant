var structEnchantDictionarySuggestNotImplemented__TestFixture =
[
    [ "EnchantDictionarySuggestNotImplemented_TestFixture", "structEnchantDictionarySuggestNotImplemented__TestFixture.html#a4050f4dac01289b5360d70426b240f82", null ]
];